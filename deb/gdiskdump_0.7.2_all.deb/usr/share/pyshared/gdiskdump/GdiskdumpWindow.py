# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2011 Andreas Wilhelm <andywilhelm@online.de>
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 2, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import sys
import os
import pynotify

import gettext
from gettext import gettext as _
gettext.textdomain('gdiskdump')


import gtk
import logging
logger = logging.getLogger('gdiskdump')

import subprocess
import gobject
import signal

from gdiskdump_lib import Window
from gdiskdump_lib.gdiskdumpconfig import get_data_path as getdatapath
from gdiskdump.AboutGdiskdumpDialog import AboutGdiskdumpDialog

# See gdiskdump_lib.Window.py for more details about how this class works
class GdiskdumpWindow(Window):
    __gtype_name__ = "GdiskdumpWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(GdiskdumpWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutGdiskdumpDialog

        # Code for other initialization actions should be added here.
        self.input=[None,None,None,None]
        self.output=[None,None,None]
        self.get_partition_liststore()
        self.get_hd_liststore()
        self.datapath =getdatapath()
        filter = gtk.FileFilter()
        filter.set_name(_('All Files'))
        filter.add_pattern('*')
        self.all_filter=filter
        filter = gtk.FileFilter()
        filter.set_name('img')
        filter.add_pattern('*.img')
        self.img_filter=filter
        filter = gtk.FileFilter()
        filter.set_name('img')
        filter.add_pattern('*')
        self.empty_img_filter=filter
        self.builder.get_object("i_filechooserwidget").add_filter(self.img_filter)
        self.builder.get_object("i_filechooserwidget").add_filter(self.all_filter)
        self.builder.get_object("o_filechooserwidget").add_filter(self.empty_img_filter)
        self.builder.get_object("o_filechooserwidget").add_filter(self.all_filter)
        print 'finished initializing' 


    def get_hd_liststore(self):
        print 'start hd_liststore'
        liststore=self.builder.get_object("hd_liststore")
        process = subprocess.Popen(['fdisk','-l'],stdout=subprocess.PIPE,shell=False)
        outstr,err=process.communicate()
        pix=gtk.gdk.pixbuf_new_from_file(getdatapath() +'/media/drive-harddisk.svg')
        devlist=outstr.splitlines()
        for i in range(len(devlist)):
            if len(devlist[i].split(', ')) == 2 and len(devlist[i].split()) <= 7 and devlist[i].split()[1].startswith('/dev/'):
                hdinfo=devlist[i].split()
                print 'hdinfo:'+str(hdinfo)
                hd=hdinfo[1].rstrip(':')
                print 'hd:'+str(hd)
                blocks=0
                #language support
                if hdinfo[4].strip(' ').isdigit():
                    size=hdinfo[4].replace(' ','')
                    print 'size:'+size
                else:
                    size=hdinfo[5].replace(' ','')                    
                    print 'size:'+size
                convsize=self.convert_bytes(size)                
                rowiter=liststore.append()
                liststore.set(rowiter,0,pix,1,hd,2,blocks,3,size,4,convsize)
        print 'got hd list'        
        
    def get_partition_liststore(self):
        liststore=self.builder.get_object("partition_liststore")
        process = subprocess.Popen(['fdisk', '-l'],stdout=subprocess.PIPE,shell=False)
        outstr,err=process.communicate()
        pix=gtk.gdk.pixbuf_new_from_file(getdatapath() +'/media/drive-harddisk.svg')
        devlist=outstr.splitlines()
        for i in range(len(devlist)):
            if devlist[i].startswith(('/dev/')):
                row=devlist[i].replace('*','')
                partinfo=row.split(None,5)
                part=partinfo[0]
                blocks=partinfo[3].strip('+ ')
                size=(int(blocks) * 1024)
                convsize=self.convert_bytes(size)
                system=partinfo[5]
                rowiter=liststore.append()
                liststore.set(rowiter,0,pix,1,part,2,blocks,3,size,4,convsize,5,system)
        print 'got partition list'



    def on_i_format_combobox_changed(self, widget, data=None):
        page=self.builder.get_object("i_format_combobox").get_active_text()
        formnotebook=self.builder.get_object("i_notebook")
        self.builder.get_object("i_fwd_button").set_sensitive(False)
        if page==_("File"):
            formnotebook.set_current_page(1)
        if page==_("Harddrive"):
            formnotebook.set_current_page(2)
        if page==_("Partition"):
            formnotebook.set_current_page(3)
        
    def on_o_format_combobox_changed(self, widget, data=None):
        page=self.builder.get_object("o_format_combobox").get_active_text()
        formnotebook=self.builder.get_object("o_notebook")
        self.builder.get_object("o_fwd_button").set_sensitive(False)
        if page==_("File"):
            formnotebook.set_current_page(1)
        if page==_("Harddrive"):
            formnotebook.set_current_page(2)
        if page==_("Partition"):
            formnotebook.set_current_page(3)
            
    #obselete
    def on_i_filechooserbutton_clicked(self, widget, data=None):
        dialog = gtk.FileChooserDialog("Open..",None,gtk.FILE_CHOOSER_ACTION_OPEN,(gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL,gtk.STOCK_OPEN, gtk.RESPONSE_OK))
        dialog.set_default_response(gtk.RESPONSE_OK)
        dialog.add_filter(self.img_filter)
        dialog.add_filter(self.all_filter)
        response = dialog.run()
        if response == gtk.RESPONSE_OK:
            print dialog.get_filename(), 'selected'
            self.builder.get_object("i_filechooserbutton").set_label(dialog.get_filename())
            self.input=[dialog.get_filename(),os.path.getsize(dialog.get_filename()),'file',None]
            self.builder.get_object("i_fwd_button").set_sensitive(True)
        elif response == gtk.RESPONSE_CANCEL:
            print 'Closed, no files selected'
        dialog.destroy()


    def on_i_filechooserwidget_changed(self, widget, data=None):
        iwidget = self.builder.get_object("i_filechooserwidget")
        i_filename = iwidget.get_filename()
        if i_filename != None :
            print i_filename, _('selected')
            self.builder.get_object("i_filechooser_path").set_label(i_filename)
            self.input=[i_filename,os.path.getsize(i_filename),'file',None]
            self.builder.get_object("i_fwd_button").set_sensitive(True)
        
    def on_o_filechooserwidget_changed(self, widget, data=None):
        owidget = self.builder.get_object("o_filechooserwidget")
        o_filename = owidget.get_filename()            
        if o_filename != None :
            if o_filename != self.builder.get_object("o_filechooser_path").get_label() :
                o_filter = self.builder.get_object("o_filechooserwidget").get_filter().get_name()
                if o_filter == 'img' :
                    o_filename = o_filename + '.img'
                print o_filename, _('selected')            
            self.builder.get_object("o_filechooser_path").set_label(o_filename)
            s= os.statvfs(owidget.get_current_folder())
            freebytes=long(s.f_bavail * s.f_frsize)
            self.output=[o_filename,freebytes,'file']
            self.builder.get_object("o_fwd_button").set_sensitive(True)

    #obselete
    def on_o_filechooserbutton_clicked(self, widget, data=None):
        dialog = gtk.FileChooserDialog("Save as..",None,gtk.FILE_CHOOSER_ACTION_SAVE,(gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL,gtk.STOCK_OK, gtk.RESPONSE_OK))
        dialog.set_default_response(gtk.RESPONSE_OK)
        dialog.add_filter(self.img_filter)
        dialog.add_filter(self.all_filter)        
        response = dialog.run()
        if response == gtk.RESPONSE_OK:
            print dialog.get_filename(), 'selected'
            self.builder.get_object("o_filechooserbutton").set_label(dialog.get_filename())
            s= os.statvfs(dialog.get_current_folder())
            freebytes=long(s.f_bavail * s.f_frsize)
            self.output=[dialog.get_filename(),freebytes,'file']            
            self.builder.get_object("o_fwd_button").set_sensitive(True)
        elif response == gtk.RESPONSE_CANCEL:
            print 'Closed, no files selected'
        dialog.destroy()       

    def dspaceerr_ok(self, widget, data=None):
        self.builder.get_object("space_err_messagedialog").hide()

    def on_i_fwd_button_clicked(self, widget, data=None):
        self.builder.get_object("stage_notebook").set_current_page(1)

    def on_o_back_button_clicked(self, widget, data=None):
        self.builder.get_object("stage_notebook").set_current_page(0)
        
    def on_o_fwd_button_clicked(self, widget, data=None):
        if long(self.input[1]) > long(self.output[1]):
            print _('not enough free space available')
            self.builder.get_object("space_err_messagedialog").show()
        else:
            self.builder.get_object("stage_notebook").set_current_page(2)
            self.builder.get_object("ipath_label").set_text(self.input[0])
            self.builder.get_object("opath_label").set_text(self.output[0])
        
    def on_new_button_clicked(self, widget, data=None):
        self.builder.get_object("stage_notebook").set_current_page(0)

    def on_start_dd_button_clicked(self, widget, data=None):
        self.builder.get_object("ddstart_warning_dialog").show()
        
    def start_dd_process(self, widget, response):
        if response==gtk.RESPONSE_OK:
            self.builder.get_object("ddstart_warning_dialog").hide()
            self.builder.get_object("abort_dd_button").set_sensitive(True)
            self.builder.get_object("start_dd_button").set_sensitive(False)
            self.builder.get_object("dd_back_button").set_sensitive(False)
            self.builder.get_object("new_button").set_sensitive(False)
            print 'dumping-------------'
            prefix=self.get_advanced_settings()
            inputp='if='+self.input[0]
            outputp='of='+self.output[0]
            print self.input
            print self.output
            
            command=['dd',inputp,outputp]+prefix
            print command
            self.process = subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False)
            self.timer=gobject.timeout_add(1000, self.progressbar_timeout)

        elif response==gtk.RESPONSE_CANCEL:
            self.builder.get_object("ddstart_warning_dialog").hide()

        
    def on_abort_dd_button_clicked(self, widget, data=None):
        print _('dumping aborted')
        self.process.kill()
        gobject.source_remove(self.timer)
        self.builder.get_object("abort_dd_button").set_sensitive(False)
        self.builder.get_object("start_dd_button").set_sensitive(True)
        self.builder.get_object("dd_back_button").set_sensitive(True)
        self.builder.get_object("new_button").set_sensitive(True)
        
    def progressbar_timeout(self):
        isize=float(self.input[3])
        status=self.get_dd_status()
        osize=float(status[0])
        #zero division errors,because device is not ready
        if osize==0:
            osize=1
        eltime=status[2]
        if eltime==0.0:
            eltime=1.0

        remtime=int((isize-osize)/(osize/float(eltime)))
        time="EL: "+self.convert_seconds(eltime)+"/ETA: "+self.convert_seconds(abs(remtime))
        frac=(osize/isize)
        #print (osize/(isize*1.0))
        if frac <= 1.0: 
            self.builder.get_object("dd_progressbar").set_fraction(frac)
        self.builder.get_object("dd_progressbar").set_text(str(int(frac*100))+"%")
        self.builder.get_object("ddconvsize_label").set_text(status[1])
        self.builder.get_object("ddeltime_label").set_text(time)
        self.builder.get_object("ddspeed_label").set_text(status[3])
        if frac<1.0:
            return True
        else:
            self.builder.get_object("abort_dd_button").set_sensitive(False)
            #self.builder.get_object("start_dd_button").set_sensitive(True)
            self.builder.get_object("dd_back_button").set_sensitive(True)
            self.builder.get_object("new_button").set_sensitive(True)      
            self.process.wait()
            print _('dumping finished')
            if pynotify.init("gdiskdump"):
                n = pynotify.Notification ("Gdiskdump",_("The dumping Process finished succesfully."))
                try:
                    n.show()
                except:
                    print "could not show a notification"
            else:
                print "there was a problem initializing the pynotify module"
            return False
               
        
    def get_dd_status(self):
        self.process.send_signal(signal.SIGUSR1)
        self.process.stderr.flush()
        _ = self.process.stderr.readline()
        self.process.stderr.flush()
        _ = self.process.stderr.readline()
        self.process.stderr.flush()
        outstrr = self.process.stderr.readline()
        print outstrr
        #language support
        if outstrr.find(', ') !=-1 :
            status=outstrr.split(', ')
        else:
            status=outstrr.split(',')
        sizestat=status[0].split('(')[0].split()
        sizestat[0]=sizestat[0].strip('abcdefghijklmop ')
        if sizestat[0].isdigit():
            size=sizestat[0]
        else:
            size=sizestat[1]

        convsize=self.convert_bytes(size)
        eltime=int(status[1].replace(',','.').split('.')[0].strip(' '))
        speed=status[2].strip('\n')
        return [size,convsize,eltime,speed]


    def get_advanced_settings(self):
    #builds the prefis for dd command
        bs=self.builder.get_object("entry_bs").get_text()
        ibs=self.builder.get_object("entry_ibs").get_text()
        obs=self.builder.get_object("entry_obs").get_text()
        count=self.builder.get_object("entry_count").get_text()
        seek=self.builder.get_object("entry_seek").get_text()
        skip=self.builder.get_object("entry_skip").get_text()
        #The size to write will change if count skip or seek is used
        #if not the size stays the same
        self.input[3]=self.input[1]

        prefix=[]        
        if ibs !="" or obs !="":
            use_ibs_obs= True
            if ibs=="":
                ibs=obs
                prefix.append('ibs='+ibs)
                prefix.append('obs='+obs)
            elif obs=="":
                obs=ibs
                prefix.append('ibs='+ibs)
                prefix.append('obs='+obs)
            else:
                prefix.append('ibs='+ibs)
                prefix.append('obs='+obs)
        elif bs !="":
            prefix.append('bs='+bs)
            use_ibs_obs= False
        if seek != "":
            prefix.append('seek='+seek)
        if skip != "":
            if use_ibs_obs==True:
                self.input[3]=int(self.input[1])-(int(skip)*int(ibs))
            else:
                self.input[3]=int(self.input[1])-(int(skip)*int(bs))
            prefix.append('skip='+skip)
        if count != "":
            if use_ibs_obs==True:
                self.input[3]=int(count)*int(ibs)
            else:
                self.input[3]=int(count)*int(bs)
            prefix.append('count='+count)
        return prefix
               
        
    def on_ipart_treeview_cursor_changed(self, widget, data=None):
        selected=self.builder.get_object("ipart_treeview").get_selection()
        model,itr=selected.get_selected()
        self.input[0]=self.builder.get_object("partition_liststore").get_value(itr,1)
        self.input[1]=self.builder.get_object("partition_liststore").get_value(itr,3)
        self.input[2]='partition'
        self.builder.get_object("i_fwd_button").set_sensitive(True)
        
    def on_opart_treeview_cursor_changed(self, widget, data=None):
        selected=self.builder.get_object("opart_treeview").get_selection()
        model,itr=selected.get_selected()
        self.output[0]=self.builder.get_object("partition_liststore").get_value(itr,1)
        self.output[1]=self.builder.get_object("partition_liststore").get_value(itr,3)
        self.output[2]='partition'
        self.builder.get_object("o_fwd_button").set_sensitive(True)

    def on_ihd_treeview_cursor_changed(self, widget, data=None):
        selected=self.builder.get_object("ihd_treeview").get_selection()
        model,itr=selected.get_selected()
        self.input[0]=self.builder.get_object("hd_liststore").get_value(itr,1)
        self.input[1]=self.builder.get_object("hd_liststore").get_value(itr,3)
        self.input[2]='hd'
        self.builder.get_object("i_fwd_button").set_sensitive(True)
        
    def on_ohd_treeview_cursor_changed(self, widget, data=None):
        selected=self.builder.get_object("ohd_treeview").get_selection()
        model,itr=selected.get_selected()
        self.output[0]=self.builder.get_object("hd_liststore").get_value(itr,1)
        self.output[1]=self.builder.get_object("hd_liststore").get_value(itr,3)
        self.output[2]='hd'
        self.builder.get_object("o_fwd_button").set_sensitive(True)
              

    def convert_seconds(self,seconds):
        minutes = seconds / 60
        seconds -= 60*minutes
        if minutes == 0:
            return "%02ds" % (seconds)
        else:
            return "%02dm:%02ds" % (minutes, seconds)        

    def convert_bytes(self,bytes):
        bytes = float(bytes)
        if bytes >= 1099511627776:
            terabytes = bytes / 1099511627776
            size = '%.2fT' % terabytes
        elif bytes >= 1073741824:
            gigabytes = bytes / 1073741824
            size = '%.2fG' % gigabytes
        elif bytes >= 1048576:
            megabytes = bytes / 1048576
            size = '%.2fM' % megabytes
        elif bytes >= 1024:
            kilobytes = bytes / 1024
            size = '%.2fK' % kilobytes
        else:
            size = '%.2fb' % bytes
        return size                



    def on_dd_back_button_clicked(self, widget, data=None):
        self.builder.get_object("stage_notebook").set_current_page(1)

    def about(self, widget, data=None):
        """about - display the about box for gdiskdump """
        about = AboutGdiskdumpDialog.NewAboutGdiskdumpDialog()
        response = about.run()
        about.destroy()

    def quit(self, widget, data=None):
        """quit - signal handler for closing the GdiskdumpWindow"""
        self.destroy()

    def on_destroy(self, widget, data=None):
        """on_destroy - called when the GdiskdumpWindow is close. """
        #clean up code for saving application state should be added here
        print 'destroy'
        gtk.main_quit()
